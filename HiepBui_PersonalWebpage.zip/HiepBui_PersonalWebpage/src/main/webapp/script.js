/**
 * 
 */
var tablinks = document.getElementsByClassName("tab-links")
var tabcontents = document.getElementsByClassName("tab-contents")
function opentab(tabname){
	for(tablinks of tablinks){
		tablinks.classList.remove("active-link")
	}
	for(tabcontents of tabcontents){
		tabcontents.classList.remove("active-tab")
	}

	event.currentTarget.classList.add("active-link");
	document.getElementById(tabname).classList.add("active-tab");
	
}
const toggleIcoin = document.querySelector('.toggle-icoin')
toggleIcoin.addEventListener('click', ()=>{
	toggleIcoin.classList.toggle('bx-sun');
	document.body.classList.toggle('dark-mode')
});
	

